//
//  Model.swift
//  MyApp
//
//  Created by Nazar Savinskyi on 08.06.2021.
//

import Foundation

class ModelUser {
    var login:String
    var password:String
    var description:String
    init(login:String, password:String,description:String) {
        self.login = login
        self.password = password
        self.description = description
    }
    func Validation()->Bool{
        //
        return true
    }
}
