//
//  ViewController.swift
//  MyApp
//
//  Created by Nazar Savinskyi on 07.06.2021.
//

import UIKit

class SignInVC: UIViewController {
   

    @IBOutlet weak var LoginField: UITextField!
    @IBOutlet weak var PasswordField: UITextField!
    @IBOutlet weak var submit: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        submit.layer.cornerRadius = 15
        PasswordField.isSecureTextEntry = true
    }
    
    @IBAction func submitAction(_ sender: Any) {
        let login:String? = LoginField.text
        let password:String? = PasswordField.text
        let VM:ViewModel = ViewModel(Login: login ?? "", Password: password ?? "")
        var result = VM.CheckData()
        var alert:UIAlertController
        if result.check == false
        {
            alert = UIAlertController(title: "Wrong login or password", message: "Please check the correctness of the entered data", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            self.present(alert, animated: true)
            
        }
        else
        {
            performSegue(withIdentifier: "SignGoMain", sender: nil)
        }
    }
}
