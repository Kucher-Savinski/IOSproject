//
//  MainPage.swift
//  MyApp
//
//  Created by Nazar Savinskyi on 07.06.2021.
//

import UIKit

class MainVC: UIViewController {


    @IBOutlet weak var ProfileImage: UIImageView!
    @IBOutlet weak var ProfileName: UILabel!
    @IBOutlet weak var ProfileDesription: UILabel!
    @IBOutlet weak var image: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Mock
        let login = "system"
        //
        // (returned data from phone)
        let description = "Im a system administrator"
        //
       // ProfileName.text = login
       // ProfileImage.image = UIImage(named: "kot")
       // ProfileImage.layer.cornerRadius = ProfileImage.bounds.height / 2
       // ProfileDesription.text = description
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
