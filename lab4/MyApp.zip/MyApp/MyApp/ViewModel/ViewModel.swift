//
//  ViewModel.swift
//  MyApp
//
//  Created by Nazar Savinskyi on 08.06.2021.
//

import Foundation
class ViewModel {
    // Mock
    var LoginM:String = "system"
    var PasswordM:String = "123"
    //
    // Class arguments
    var LoginReceive = ""
    var PasswordReceive = ""
    //
    init(Login:String, Password:String){
        self.LoginReceive = Login
        self.PasswordReceive = Password
        //KNOPKA
    }
    func CheckData()->(validation:Bool,check:Bool){
        var validation:Bool = false
        var check:Bool = false
        let user:ModelUser = ModelUser(login: self.LoginReceive,password: self.PasswordReceive,description: "")
        validation = user.Validation()
        if user.login == LoginM && user.password == PasswordM {
            check = true
        }
        return (validation,check)
    }
}
