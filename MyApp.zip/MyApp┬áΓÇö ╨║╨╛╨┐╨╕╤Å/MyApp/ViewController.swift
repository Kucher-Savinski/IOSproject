//
//  ViewController.swift
//  MyApp
//
//  Created by Nazar Savinskyi on 07.06.2021.
//

import UIKit

class ViewController: UIViewController {
   

    @IBOutlet weak var submit: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        submit.layer.cornerRadius = 15
    }
}

