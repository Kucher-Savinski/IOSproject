//
//  FriendProfileVC.swift
//  MyApp
//
//  Created by Nazar Savinskyi on 09.06.2021.
//

import UIKit
var DataAboutFriend = GetDataAboutFriend(Login: SelectedFriend)
class FriendProfileVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return DataAboutFriend[3].count
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellFriendPageID", for: indexPath)
        cell.textLabel?.text = DataAboutFriend[3][indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let url = OpenURLAboutPrefFriend(Index: indexPath.row)
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
    }
    @IBOutlet weak var UserDescription: UILabel!
    @IBOutlet weak var UserImage: UIImageView!
    @IBOutlet weak var UserName: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        UserName.text = DataAboutFriend[0][0]
        UserDescription.text = DataAboutFriend[2][0]
        UserImage.image = UIImage(named: DataAboutFriend[1][0])
    }
}
