//
//  AddNewFriendVC.swift
//  MyApp
//
//  Created by Nazar Savinskyi on 11.06.2021.
//

import UIKit
var AllUsers = AllUsersFromDB(Login: CurrentLogin)
class AddNewFriendVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var tableView: UITableView!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return AllUsers.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellAddFriendPageID", for: indexPath)
        cell.textLabel?.text = AllUsers[indexPath.row][0]
        cell.imageView?.image = UIImage(named: AllUsers[indexPath.row][1])
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        AddNewFriend(Index: indexPath.row)
        var alert:UIAlertController
        alert = UIAlertController(title: "New friend added succesfully", message: "", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Hide", style: .cancel, handler: {_ in self.performSegue(withIdentifier: "AddFriendGoFriends", sender: nil)}))
        self.present(alert, animated: true)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
