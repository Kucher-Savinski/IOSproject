//
//  ViewController.swift
//  MyApp
//
//  Created by Nazar Savinskyi on 07.06.2021.
//

import UIKit

class SignInVC: UIViewController {
    private let SignGoMain = "SignGoMain"
    @IBOutlet weak var LoginField: UITextField!
    @IBOutlet weak var PasswordField: UITextField!
    @IBOutlet weak var submit: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        submit.layer.cornerRadius = 15
        PasswordField.isSecureTextEntry = true
    }
    // Mock
    func CheckDataInDB()->Bool{
        // Connect to Firebase and check received data
        var result = false
        if LoginField.text! == "system" && PasswordField.text! == "123"{
            result = true
        }
        return result
    }
    func GetFromDBDesrAndImage()->(DescriptionDB:String, ImageDB:String){
        // Search login and return description and image name
        return ("I am a system administrator","Котик")
    }
    //
    @IBAction func submitAction(_ sender: Any) {
        let result = CheckDataInDB()
        var alert:UIAlertController
        if result == false
        {
            alert = UIAlertController(title: "Wrong login or password", message: "Please check the correctness of the entered data", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Hide", style: .cancel, handler: nil))
            self.present(alert, animated: true)
        }
        else
        {
            let data = GetFromDBDesrAndImage()
            CurrentDescription = data.DescriptionDB
            CurrentImage = data.ImageDB
            CurrentLogin = LoginField.text!
            performSegue(withIdentifier: "SignGoMain", sender: nil)
        }
    }
}
