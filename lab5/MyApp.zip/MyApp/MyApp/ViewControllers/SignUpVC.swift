//
//  SignUpVC.swift
//  MyApp
//
//  Created by Nazar Savinskyi on 09.06.2021.
//

import UIKit

class SignUpVC: UIViewController {

    @IBOutlet weak var LoginField: UITextField!
    @IBOutlet weak var PasswordField: UITextField!
    @IBOutlet weak var RepeatPasswordField: UITextField!
    @IBOutlet weak var submit: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        submit.layer.cornerRadius = 15
        PasswordField.isSecureTextEntry = true
        RepeatPasswordField.isSecureTextEntry = true
    }
    // Mock
    func LoginHasAlready()->Bool{
        // Connect to Firebase and check login
        var result = false
        if LoginField.text! == "system"{
            result = true
        }
        return result
    }
    func InsertNewUserToDB()->Bool{
        // Connect to Firebase and insert new user
        var result:Bool
        do {
            try result = true // Add new user to DB and if everything is good result = true
        } catch {
            result = false
        }
        return result
    }
    //
    func SignUp()->Int
    {
        var result = -1
        CurrentLogin = LoginField.text!
        CurrentPassword = PasswordField.text!
        if Validation()
        {
            if InsertNewUserToDB()
            {
                result = 2
            }
            else
            {
                result = 1
            }
        }
        else
        {
            result = 0
        }
        return result
    }
    @IBAction func pressSubmit(_ sender: Any) {
        var alert:UIAlertController
        if LoginField.text == "" || PasswordField.text == "" || RepeatPasswordField.text == ""
        {
            alert = UIAlertController(title: "Some field is empty", message: "Please try again", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Hide", style: .cancel, handler: nil))
            self.present(alert, animated: true)
        }
        else if PasswordField.text != RepeatPasswordField.text
        {
            alert = UIAlertController(title: "Entered passwords do not match", message: "Please try again", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Hide", style: .cancel, handler: nil))
            self.present(alert, animated: true)
        }
        else {
            var alert:UIAlertController
            if LoginHasAlready() {
                alert = UIAlertController(title: "Login is already exist", message: "Please choose another", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Hide", style: .cancel, handler: nil))
                self.present(alert, animated: true)
                }
            else{
                if SignUp() == 2{
                    alert = UIAlertController(title: "Registration completed succesfully", message: "", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Hide", style: .cancel, handler: {_ in self.performSegue(withIdentifier: "SignUpGoSingIn", sender: nil)}))
                    self.present(alert, animated: true)
                }
                else if SignUp() == 1
                {
                    alert = UIAlertController(title: "Some problems with Database", message: "", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Hide", style: .cancel, handler: nil))
                    self.present(alert, animated: true)
                }
                else if SignUp() == 0
                {
                    alert = UIAlertController(title: "Your login or password does not meet the requirements", message: "Check your login it must be from 1 to 16 symbols and your password it must be from 6 to 16 symbols and not contain space", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Hide", style: .cancel, handler: nil))
                    self.present(alert, animated: true)
                }
            }
        }
    }
}


