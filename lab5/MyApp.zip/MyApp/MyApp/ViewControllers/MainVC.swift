//
//  MainPage.swift
//  MyApp
//
//  Created by Nazar Savinskyi on 07.06.2021.
//

import UIKit

class MainVC: UIViewController {
    @IBOutlet weak var ProfileImage: UIImageView!
    @IBOutlet weak var ProfileName: UILabel!
    @IBOutlet weak var ProfileDesription: UILabel!
    @IBOutlet weak var image: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        getprofileinfo()
    }
    func getprofileinfo()
    {
        ProfileName.text = CurrentLogin
        ProfileImage.image = UIImage(named: CurrentImage)
        ProfileDesription.text = CurrentDescription
    }
}
