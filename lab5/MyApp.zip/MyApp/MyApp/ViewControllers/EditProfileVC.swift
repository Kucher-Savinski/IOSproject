//
//  EditProfileVC.swift
//  MyApp
//
//  Created by Nazar Savinskyi on 09.06.2021.
//

import UIKit
var ImageArr = GetArrOfImages()
class EditProfileVC: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet weak var DescriptionField: UITextField!
    @IBOutlet weak var ImageView: UIImageView!
    @IBOutlet weak var Picker: UIPickerView!
    @IBOutlet weak var NameField: UITextField!
    @IBOutlet weak var submit: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        submit.layer.cornerRadius = 15
        Picker.delegate = self
        Picker.dataSource = self
        self.ImageView.image = UIImage(named: "Котик")
        // Do any additional setup after loading the view.
    }
    @IBAction func pressSubmit(_ sender: Any) {
        var alert:UIAlertController
        if NameField.text == "" || DescriptionField.text == ""
        {
            alert = UIAlertController(title: "One or both fields is empty", message: "Please, try again", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Hide", style: .cancel, handler: nil))
            self.present(alert, animated: true)
        }
        else
        {
            CurrentDescription = DescriptionField.text!
            CurrentLogin = NameField.text!
            alert = UIAlertController(title: "Editing completed succesfully", message: "", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Hide", style: .cancel, handler: {_ in self.performSegue(withIdentifier: "EditPageGoMain", sender: nil)}))
            self.present(alert, animated: true)
        }
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        return ImageArr.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        return ImageArr[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        switch row
        {
        case row:
            self.ImageView.image = UIImage(named: ImageArr[row])
            CurrentImage = ImageArr[row]
        default:
            break
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
