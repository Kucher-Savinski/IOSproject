//
//  AddPreferenceVC.swift
//  MyApp
//
//  Created by Nazar Savinskyi on 09.06.2021.
//

import UIKit

class AddPreferenceVC: UIViewController {

    @IBOutlet weak var LinkField: UITextField!
    @IBOutlet weak var NameField: UITextField!
    @IBOutlet weak var submit: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        submit.layer.cornerRadius = 15
        // Do any additional setup after loading the view.
    }
    
    @IBAction func PressSubmit(_ sender: Any) {
        if NameField.text == "" || LinkField.text == ""
        {
            var alert:UIAlertController
            alert = UIAlertController(title: "One or both fields is empty", message: "Please, try again", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Hide", style: .cancel, handler: nil))
            self.present(alert, animated: true)
        }
        else
        {
            InsertData(DataRecieve: NameField.text, DataURLRecieve: LinkField.text)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
