//
//  ModelEdit.swift
//  MyApp
//
//  Created by Nazar Savinskyi on 11.06.2021.
//

import Foundation

// Mock
// returned from server
func GetArrOfImages()->[String]
{
    return ["Котик","Планктон","Лиса"]
}
//
