//
//  ModelTablePref.swift
//  MyApp
//
//  Created by Nazar Savinskyi on 11.06.2021.
//

import Foundation

// Mock
func DataFromDB(Login:String?) -> (data:[String],dataURL:[String])
{
    // Connect to Firebase and read names + URLs of preferences
    return (["Iphone 12","Сумка Gucci","Кольцо с бриллиантом","Часы Rolex"], ["http://google.com","http://google.com","http://google.com","http://google.com"])
}
//
func InsertData(DataRecieve:String?,DataURLRecieve:String?)
{
    Data.data.append(DataRecieve!)
    Data.dataURL.append(DataURLRecieve!)
}
func RemoveData(Index:Int)
{
    Data.data.remove(at: Index)
    Data.dataURL.remove(at: Index)
}
func OpenURL(Index:Int) -> URL
{
    let url = URL(string: Data.dataURL[Index])
    return url!
}
