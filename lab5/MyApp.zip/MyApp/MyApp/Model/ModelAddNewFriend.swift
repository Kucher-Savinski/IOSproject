//
//  ModelAddNewFriend.swift
//  MyApp
//
//  Created by Nazar Savinskyi on 11.06.2021.
//

import Foundation

func AllUsersFromDB(Login:String?) -> [[String]]
{
    // returns all users besides current and friends
    return [["katya","Котик"],["vova","Планктон"],["nazar","Лиса"]]
}
func AddNewFriend(Index:Int)
{
    DataFriends.append(AllUsers[Index])
    AllUsers.remove(at: Index)
}
//
