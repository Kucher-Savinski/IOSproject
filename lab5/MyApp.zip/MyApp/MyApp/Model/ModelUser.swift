//
//  Model.swift
//  MyApp
//
//  Created by Nazar Savinskyi on 08.06.2021.
//

import Foundation

var CurrentLogin = ""
var CurrentPassword = ""
var CurrentDescription = ""
var CurrentImage = ""

func Validation()->Bool{
    var result = false
    if CurrentLogin.count > 1 && CurrentLogin.count < 16 && CurrentPassword.count < 16 && CurrentPassword.count > 6 && !CurrentPassword.contains(" ")
    {
        result = true
    }
    return result
}
