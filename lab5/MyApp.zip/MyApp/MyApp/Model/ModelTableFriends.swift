//
//  ModelTableFriends.swift
//  MyApp
//
//  Created by Nazar Savinskyi on 11.06.2021.
//

import Foundation
// Mock
func DataFromDBFriends(Login:String?) -> [[String]]
{
    // Connect to Firebase and read names + URLs of preferences
    return [["vasya","Планктон"],["petya","Лиса"]]
}
//func InsertDataFriends(DataRecieve:String?)
//{
   // DataFriends.append(DataRecieve!)
//}
func RemoveDataFriends(Index:Int)
{
    AllUsers.append(DataFriends[Index])
    DataFriends.remove(at: Index)
}
