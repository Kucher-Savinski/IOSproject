//
//  ModelFriendPage.swift
//  MyApp
//
//  Created by Nazar Savinskyi on 11.06.2021.
//

import Foundation
// Mock
func GetDataAboutFriend(Login:String?) -> [[String]]
{
    return [["vasya"],["Планктон"],["i am superman"],["Часы Lacoste","Iphone XR"],["https://google.com","https://google.com"]]
}
//
func OpenURLAboutPrefFriend(Index:Int) -> URL
{
    let url = URL(string: DataAboutFriend[4][Index])
    return url!
}
